package com.jungyong.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 처리할 버튼을 찾으세요.
        Button restart = findViewById(R.id.restart);

        //2. 이벤트(클릭) 했을 때, 처리할 것을 셋팅
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "버튼을 누르셨군요..", Toast.LENGTH_LONG).show();

                //3. 처리할 내용은 PaulActivity를 시작

                Intent go = new Intent(getApplicationContext(), PaulActivity.class);
                startActivity(go);


            }
        });


    }
}
